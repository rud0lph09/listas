public class Principal{
	public static void main(String[] args) {
		lista l = new lista();
		l.InsertarAlInicio("a");
		l.InsertarAlFinal("b");
		l.InsertarAlFinal("c");
		l.InsertarAlFinal("d");
		l.InsertarAlFinal("e");
		l.Listar();
	}
}